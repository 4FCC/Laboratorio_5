#include <iostream>

using namespace std;

int mcd(int a, int b) {
	if (a > b, b == 0) {
		return a;
	}
	else {
		mcd(b, a % b);
	}
}

int main() {
	int a, b;

	cout << "Calaculadora de MCD\n";
	cout << "Ingresa el numero 'a': "; cin >> a;
	cout << "Ingresa el numero 'b': "; cin >> b;
	cout << "El MCD entre " << a << " y " << b << " es: " << mcd(a, b);
}