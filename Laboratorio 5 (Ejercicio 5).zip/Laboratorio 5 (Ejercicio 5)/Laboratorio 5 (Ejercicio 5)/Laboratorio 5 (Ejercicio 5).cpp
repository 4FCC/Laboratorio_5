#include <iostream>

using namespace std;

int f(int n) {
    int d = 1;
    for (int i = 1; i <= n; i++) {
        int a = f(i - 1);
        int b = i / 2;
        int c = f(b);
        d = a * b + c;
    }
    return d;
}

int main() {
	cout << f(5) << endl; // 15
	return 0;
}