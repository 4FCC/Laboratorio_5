#include <iostream>

using namespace std;

int main() {
    int a[5], b[4], c[3], d[2], e;

    // Asigna valores a los elementos del arreglo a
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    a[4] = 5;

    // Calcula los valores de b
    b[0] = a[0] + a[1];
    b[1] = a[1] + a[2];
    b[2] = a[2] + a[3];
    b[3] = a[3] + a[4];

    // Calcula los valores de c
    c[0] = b[0] + b[1];
    c[1] = b[1] + b[2];
    c[2] = b[2] + b[3];

    // Calcula los valores de d
    d[0] = c[0] + c[1];
    d[1] = c[1] + c[2];

    // Calcula el valor de e
    e = d[0] + d[1];

    // Imprimir resultado final
    cout << e << "\n";
    cout << d[0] << " " << d[1] << " " << "\n";
    cout << c[0] << " " << c[1] << " " << c[2] << "\n";
    cout << b[0] << " " << b[1] << " " << b[2] << " " << b[3] << "\n";
    cout << a[0] << " " << a[1] << " " << a[2] << " " << a[3] << " " << a[4] << "\n";

    return 0;
}
