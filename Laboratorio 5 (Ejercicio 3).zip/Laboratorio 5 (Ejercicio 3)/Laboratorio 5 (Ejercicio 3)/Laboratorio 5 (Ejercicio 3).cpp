#include <iostream>

using namespace std;

void imprimirInverso(char Palabra[], int n) {
    if (n < 0) {
        return; // No hace nada cuando n es negativo
    }
    else {
        cout << Palabra[n];
        imprimirInverso(Palabra, n - 1);
    }
}

int main() {
    char Palabra[20];

    cout << "Escribe una palabra: "; cin >> Palabra;

    int n = strlen(Palabra);

    cout << "Su palabra inversa es: "; imprimirInverso(Palabra, n - 1); cout << endl;

    return 0;
}
